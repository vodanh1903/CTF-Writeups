# Example Markdown

This is an example of a Markdown file.

- Item 1
- Item 2
- Item 3

**Bold Text**

*Italic Text*
